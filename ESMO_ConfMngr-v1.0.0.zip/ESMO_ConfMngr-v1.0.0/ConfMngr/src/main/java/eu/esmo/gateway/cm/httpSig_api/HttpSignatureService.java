package eu.esmo.gateway.cm.httpSig_api;
//package eu.esmo.httpSigs.lib.signatures;


//import eu.esmo.httpSigs.lib.enums.HttpResponseEnum;
//import eu.esmo.gateway.acm.domain.HttpResponseEnum;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import javax.servlet.http.HttpServletRequest;

import eu.esmo.gateway.cm.rest_api.controllers.ewp.EwpRegistryClient;
import eu.esmo.gateway.cm.rest_api.controllers.ewp.EwpRegistryGetApiController;
import eu.esmo.gateway.cm.rest_api.domain.HttpResponseEnum;
import eu.esmo.gateway.cm.rest_api.domain.MsMetadataList;
/**
 *
 * @author nikos, Atos
 */
public interface HttpSignatureService {

	public HttpResponseEnum verifySignature(HttpServletRequest httpRequest, MsMetadataList allMicroservices, EwpRegistryGetApiController ewpRegistryServ) ;
	
    public String generateSignature(String hostUrl, String method, String uri, Object postParams, String contentType, String requestId)
            throws NoSuchAlgorithmException, KeyStoreException, UnrecoverableKeyException, UnsupportedEncodingException, IOException, UnsupportedEncodingException;
     
}
