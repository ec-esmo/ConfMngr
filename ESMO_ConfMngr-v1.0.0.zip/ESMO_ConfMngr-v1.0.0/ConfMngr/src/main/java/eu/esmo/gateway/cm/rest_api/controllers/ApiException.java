package eu.esmo.gateway.cm.rest_api.controllers;

@javax.annotation.Generated(value = "eu.esmo.gateway.cm.codegen.languages.SpringCodegen", date = "2018-12-10T12:53:06.421Z")

public class ApiException extends Exception{
    private int code;
    public ApiException (int code, String msg) {
        super(msg);
        this.code = code;
    }
}
