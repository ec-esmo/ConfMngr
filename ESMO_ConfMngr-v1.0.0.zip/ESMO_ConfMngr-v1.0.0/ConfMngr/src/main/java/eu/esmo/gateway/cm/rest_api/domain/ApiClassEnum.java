package eu.esmo.gateway.cm.rest_api.domain;

import com.fasterxml.jackson.annotation.JsonValue;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets apiClassEnum
 */
public enum ApiClassEnum {
  
  SP("SP"),
  
  IDP("IDP"),
  
  AP("AP"),
  
  GW("GW"),
  
  ACM("ACM"),
  
  SM("SM"),
  
  CM("CM");

  private String value;

  ApiClassEnum(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static ApiClassEnum fromValue(String text) {
    for (ApiClassEnum b : ApiClassEnum.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}

