package eu.esmo.gateway.cm.rest_api.controllers.mdmicroservices;

import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import eu.esmo.gateway.cm.rest_api.domain.MsMetadataList;

@javax.annotation.Generated(value = "eu.esmo.gateway.cm.codegen.languages.SpringCodegen", date = "2018-12-10T12:53:06.421Z")

@Api(value = "metadata", description = "the metadata API")
public interface ClassMicroservicesGetApi {

    @ApiOperation(value = "Get the configuration metadata for all microservices of the specified api class.", nickname = "classMicroservicesGet", notes = "Get ...", response = MsMetadataList.class, tags={ "Registry", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Successful operation", response = MsMetadataList.class),
        @ApiResponse(code = 404, message = "Bad microservice type or none found") })
    @RequestMapping(value = "cm/metadata/microservices/{apiClass}",
        produces = { "application/json" }, 
        method = RequestMethod.GET)
    ResponseEntity<MsMetadataList> classMicroservicesGet(@ApiParam(value = "",required=true, 
    allowableValues = "SP, IDP, AP, GW, ACM, SM, CM") @PathVariable("apiClass") String apiClass);


}

//public interface ClassMicroservicesGetApi {
//
//    @ApiOperation(value = "Get the configuration metadata for all microservices of the specified api class.", nickname = "classMicroservicesGet", notes = "Get ...", response = MsMetadataList.class, tags={ "Registry", })
//    @ApiResponses(value = { 
//        @ApiResponse(code = 200, message = "Successful operation", response = MsMetadataList.class),
//        @ApiResponse(code = 404, message = "Bad microservice type or none found") })
//    @RequestMapping(value = "/metadata/microservices",
//        produces = { "application/json" }, 
//        method = RequestMethod.GET)
//    ResponseEntity<MsMetadataList> classMicroservicesGet(@RequestParam(value = "apiClass",required=true) String apiClass);
//    
//}
