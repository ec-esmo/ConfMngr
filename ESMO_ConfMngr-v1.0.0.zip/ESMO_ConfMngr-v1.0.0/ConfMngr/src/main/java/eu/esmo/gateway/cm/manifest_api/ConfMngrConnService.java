package eu.esmo.gateway.cm.manifest_api;


import eu.esmo.gateway.cm.rest_api.domain.EsmoManifest;

public interface ConfMngrConnService 
{
	
	public EsmoManifest getEsmoManifest (String cmUrl); //getEsmoMetadata
	
}

