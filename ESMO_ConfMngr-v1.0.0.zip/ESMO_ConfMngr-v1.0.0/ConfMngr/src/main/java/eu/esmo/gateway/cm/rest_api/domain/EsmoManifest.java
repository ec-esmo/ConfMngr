package eu.esmo.gateway.cm.rest_api.domain;

// Gateway and local APs info
public class EsmoManifest
{
    private EntityMetadata gateway;

    private EntityMetadataList proxiedEntities;

    public EntityMetadata getGateway()
    {
        return gateway;
    }

    public void setGateway(EntityMetadata gateway)
    {
        this.gateway = gateway;
    }

    public EntityMetadataList getProxiedEntities()
    {
        return proxiedEntities;
    }

    public void setProxiedEntities(EntityMetadataList proxiedEntities)
    {
        this.proxiedEntities = proxiedEntities;
    }
}
