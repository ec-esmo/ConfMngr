package eu.esmo.gateway.cm.rest_api.services.mdexternalentities;


import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import eu.esmo.gateway.cm.configuration.Constants;
import eu.esmo.gateway.cm.rest_api.domain.EntityMetadataList;
import eu.esmo.gateway.cm.utils.Utils;

@Service
public class ClassEntitiesGetServiceImp implements ClassEntitiesGetService{
	
	@Value ( "${gateway.cm.externalentities.path}" )
	String externalEntitiesPath;
	
	@Value ( "${gateway.cm.externalentities.file.secondpart}" )
	String fileSecondPart;
	
	@Override
	public EntityMetadataList classEntitiesGet (String entityClassId) throws Exception {
	// TO BE AWARE of the fileName expected!!	
		
		EntityMetadataList classEntities = new EntityMetadataList();
		String fileStringValue;
		
		try {
			
			
			fileStringValue = Utils.readFile (externalEntitiesPath + entityClassId + fileSecondPart);
		
			Gson gson = new Gson();
			classEntities = gson.fromJson(fileStringValue, EntityMetadataList.class);
			if (classEntities.isEmpty())
				throw new Exception(Constants.ENTITIES_NOT_FOUND);
			
		} catch (IOException e){
			throw new IOException(e);
		} catch (JsonSyntaxException e) {
			throw new JsonSyntaxException(e);
		} catch (Exception e){			
			throw new Exception(e);
		}
		
		return classEntities;
	}

}

