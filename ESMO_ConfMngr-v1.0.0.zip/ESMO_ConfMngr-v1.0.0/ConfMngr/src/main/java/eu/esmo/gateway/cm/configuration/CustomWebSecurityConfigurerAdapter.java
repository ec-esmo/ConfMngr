/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eu.esmo.gateway.cm.configuration;

import eu.esmo.gateway.cm.filters.HttpSignatureFilter;
import eu.esmo.gateway.cm.httpSig_api.HttpSignatureService;
import eu.esmo.gateway.cm.httpSig_api.HttpSignatureServiceImpl;
import eu.esmo.gateway.cm.params_api.KeyStoreService;
import eu.esmo.gateway.cm.rest_api.controllers.ewp.EwpRegistryGetApiController;
import eu.esmo.gateway.cm.rest_api.services.mdmicroservices.AllMicroservicesGetService;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.spec.InvalidKeySpecException;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

/**
 *
 * @author nikos, Atos
 */
@Configuration
public class CustomWebSecurityConfigurerAdapter extends WebSecurityConfigurerAdapter {

    private HttpSignatureService sigServ;
    
    private KeyStoreService keysServ;
    
    private AllMicroservicesGetService allMicroservicesServ;
    
    EwpRegistryGetApiController ewpRegistryServ;
    
    @Autowired
    public CustomWebSecurityConfigurerAdapter(	KeyStoreService keysServ, 
    											AllMicroservicesGetService allMicroservicesServ,
    											EwpRegistryGetApiController ewpRegistryServ) throws KeyStoreException, UnsupportedEncodingException, NoSuchAlgorithmException, UnrecoverableKeyException, InvalidKeySpecException, IOException {

        this.sigServ = new HttpSignatureServiceImpl(DigestUtils.sha256Hex(keysServ.getHttpSigPublicKey().getEncoded()), keysServ.getHttpSigningKey());
        this.allMicroservicesServ = allMicroservicesServ;
        this.keysServ = keysServ;
        
        this.ewpRegistryServ = ewpRegistryServ;
        

    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
    	
    	
    	/*
        //http.antMatcher("/cm/**")
    	http.requestMatchers()
    			//.antMatchers("/cm/**","/ewp/esmo-metadata")
    			.antMatchers("/cm/**","/ewp/esmo-metadata", "/ewp/esmoHosts")
    			.and()
            .addFilterBefore(new HttpSignatureFilter(this.sigServ, this.allMicroservicesServ, this.ewpRegistryClient), BasicAuthenticationFilter.class)
        	.csrf().disable();
    	*/
    	
    	http.antMatcher("/**")
    		.addFilterBefore(new HttpSignatureFilter(this.sigServ, this.allMicroservicesServ, this.ewpRegistryServ), BasicAuthenticationFilter.class)
    		.csrf().disable();
    	
    }

 

}
