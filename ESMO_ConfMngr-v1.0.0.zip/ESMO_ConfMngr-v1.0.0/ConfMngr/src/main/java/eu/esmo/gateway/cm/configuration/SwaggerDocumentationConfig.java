package eu.esmo.gateway.cm.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

@javax.annotation.Generated(value = "eu.esmo.gateway.cm.codegen.languages.SpringCodegen", date = "2018-12-10T12:53:06.421Z")

@Configuration
public class SwaggerDocumentationConfig {

    ApiInfo apiInfo() {
        return new ApiInfoBuilder()
            .title("Configuration Manager")
            .description("The ConfMngr is in charge of providing the configuration sets needed by each ms in the GW deployment which includes:  \n" + 
            		"  \n" + 
            		"  *  The list of microservices:\n" + 
            		"  -- ms identifier\n" + 
            		"  -- type (i.e. SessionMngr, ConfMngr, ACM, SP, AP, IDP, GW2GW, etc.)\n" + 
            		"  -- Public keys of the ms (to be used on the client authentication in HTTP Signature)\n" + 
            		"\n" + 
            		"  -- Published APIs:\n" + 
            		"  -- API class: SessionMngr, ConfMngr, ACM, SP, AP, IDP, GW2GW  \n" + 
            		"  -- API call: e.g. attrRequest, or attrResponse  \n" + 
            		"  -- API connection type: post, get\n" + 
            		"  -- API endpoint: its URL\n" + 
            		"  \n" + 
            		"  * The list of external entities: SPs, local APs, IdPs, remote GWs, remote APs.\n" + 
            		"  \n" + 
            		"  * Internal entities: local GW configuration at the moment.\n" + 
            		"  \n" + 
            		"  * List of attributes: provided by eIDAS, eduPerson, eduOrg, schac...\n" + 
            		"  \n" + 
            		"  * EWP registry processing. \n" + 
            		"  \n" + 
            		"  \n" + 
            		"  Note: each ms will be in charge of configuring their own CA signed certificates for server TLS.\n")
            .license("")
            .licenseUrl("http://unlicense.org")
            .termsOfServiceUrl("")
            .version("0.0.8")
            .contact(new Contact("","", ""))
            .build();
    }

    @Bean
    public Docket customImplementation(){
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                    .apis(RequestHandlerSelectors.basePackage("eu.esmo.gateway.cm.rest_api"))
                    .build()
                .directModelSubstitute(org.threeten.bp.LocalDate.class, java.sql.Date.class)
                .directModelSubstitute(org.threeten.bp.OffsetDateTime.class, java.util.Date.class)
                .apiInfo(apiInfo());
    }
    
//    @Bean
//    public Docket api() {
//        return new Docket(DocumentationType.SWAGGER_2)
//                .select()
//                .apis(RequestHandlerSelectors.any())
//                .paths(PathSelectors.any())
//                .build()
//                .apiInfo(apiInfo());
//    }


}
