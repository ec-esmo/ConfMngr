package eu.esmo.gateway.cm.rest_api.services.mdinternal;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import eu.esmo.gateway.cm.configuration.Constants;
import eu.esmo.gateway.cm.rest_api.domain.EntityMetadata;
import eu.esmo.gateway.cm.utils.Utils;

@Service
public class ConfigurationGetServiceImp implements ConfigurationGetService{
	
	@Value ( "${gateway.cm.internal.path}" )
	String internalPath;
	
	@Value ( "${gateway.cm.internal.file.secondpart}" )
	String fileSecondPart;
	
	@Override
	public EntityMetadata ConfigurationGet (String confId) throws Exception {
		// TO BE AWARE of the fileName expected!!!
		
		EntityMetadata internalConf = null;
		
		String fileStringValue;
		try {
			String fileName = confId + fileSecondPart;
			// TO BE AWARE of the fileName expected
			
			fileStringValue = Utils.readFile (internalPath + fileName);
			Gson gson = new Gson();
			
			internalConf = gson.fromJson(fileStringValue, EntityMetadata.class);
			if (internalConf.equals (null))
				throw new Exception(Constants.INTERNAL_CONF_NOT_FOUND); 
				
			
		} catch (IOException e){
			throw new IOException(e);
		} catch (JsonSyntaxException e) {
			throw new JsonSyntaxException(e);
		} catch (Exception e){			
			throw new Exception(e);
		}
		
		return internalConf;
	}

}

