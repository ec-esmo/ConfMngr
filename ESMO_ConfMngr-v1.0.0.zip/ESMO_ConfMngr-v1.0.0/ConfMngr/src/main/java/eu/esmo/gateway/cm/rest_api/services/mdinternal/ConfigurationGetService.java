package eu.esmo.gateway.cm.rest_api.services.mdinternal;

import eu.esmo.gateway.cm.rest_api.domain.EntityMetadata;

public interface ConfigurationGetService {
	
	EntityMetadata ConfigurationGet (String confId) throws Exception;

}
