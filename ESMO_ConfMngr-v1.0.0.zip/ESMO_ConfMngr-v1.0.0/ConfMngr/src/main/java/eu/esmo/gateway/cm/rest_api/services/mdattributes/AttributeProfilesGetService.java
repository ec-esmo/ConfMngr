package eu.esmo.gateway.cm.rest_api.services.mdattributes;

import java.util.List;

public interface AttributeProfilesGetService {
	
	List<String> attributeProfilesGet () throws Exception;

}
