package eu.esmo.gateway.cm.rest_api.services.mdexternalentities;

import eu.esmo.gateway.cm.rest_api.domain.EntityMetadata;

public interface EntityGetService {
	
	EntityMetadata EntityGet (String entityClassId, String entityId) throws Exception;

}
