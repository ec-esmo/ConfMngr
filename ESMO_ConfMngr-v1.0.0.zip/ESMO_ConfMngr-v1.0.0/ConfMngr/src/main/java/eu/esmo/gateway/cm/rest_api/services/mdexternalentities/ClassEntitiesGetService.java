package eu.esmo.gateway.cm.rest_api.services.mdexternalentities;

import eu.esmo.gateway.cm.rest_api.domain.EntityMetadataList;

public interface ClassEntitiesGetService {
	
	EntityMetadataList classEntitiesGet (String entityClassId) throws Exception;

}
