package eu.esmo.gateway.cm.rest_api.services.mdattributes;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import eu.esmo.gateway.cm.configuration.Constants;

@Service
public class AttributeProfilesGetServiceImp implements AttributeProfilesGetService{
	
	@Value ( "${gateway.cm.attributes.path}" )
	String msFile;
	
	@Value ( "${gateway.cm.files.extension}" )
	String fileExtension;
	
	@Override
	public List<String> attributeProfilesGet ()  throws Exception {
		// TO BE AWARE of the directory name expected!!!
		
		File dir = new File(msFile);
		String[] files = dir.list();
		
		List<String> profiles = new ArrayList<String>();
		
		if (files != null && files.length != 0) {
			  String fileName = new String();			 
			  for (int x=0;x<files.length;x++) {
				  fileName = files[x];
				  
				  profiles.add(fileName.substring (0,fileName.indexOf(fileExtension)));
			  }
			    
		}
		else // Empty directory
			throw new Exception (Constants.PROFILES_NOT_FOUND);
		
		return (profiles);
	}

}

