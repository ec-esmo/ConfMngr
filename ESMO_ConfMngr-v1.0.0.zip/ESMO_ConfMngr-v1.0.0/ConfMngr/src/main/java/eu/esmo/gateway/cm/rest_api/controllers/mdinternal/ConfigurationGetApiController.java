package eu.esmo.gateway.cm.rest_api.controllers.mdinternal;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonSyntaxException;

import eu.esmo.gateway.cm.configuration.Constants;
import eu.esmo.gateway.cm.rest_api.domain.EntityMetadata;
import eu.esmo.gateway.cm.rest_api.services.mdinternal.ConfigurationGetService;
import io.swagger.annotations.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@javax.annotation.Generated(value = "eu.esmo.gateway.cm.codegen.languages.SpringCodegen", date = "2018-12-10T12:53:06.421Z")

@Controller
public class ConfigurationGetApiController implements ConfigurationGetApi {
	
	@Autowired
	private ConfigurationGetService configurationGetService;

    private static final Logger log = LoggerFactory.getLogger(ConfigurationGetApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public ConfigurationGetApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }
    
    public ResponseEntity<EntityMetadata> configurationGet(@ApiParam(value = "",required=true) @PathVariable("confId") String confId) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
        	
        	EntityMetadata internalConf = new EntityMetadata();
        	
        	try {
        		internalConf= configurationGetService.ConfigurationGet(confId);
        		return new ResponseEntity<EntityMetadata>(internalConf, HttpStatus.OK);
                }
        	catch (IOException e) {
            	log.error(Constants.FILE_ERROR, e);
        		return new ResponseEntity<EntityMetadata>(HttpStatus.NOT_FOUND);
            }
        	catch (JsonSyntaxException e) {
            	log.error(Constants.JSON_SYNTAX_ERROR, e);
        		return new ResponseEntity<EntityMetadata>(HttpStatus.NOT_FOUND);
            }
            catch (Exception e) {
        		log.error(Constants.INTERNAL_CONF_NOT_FOUND, e);
        		return new ResponseEntity<EntityMetadata>(HttpStatus.NOT_FOUND);
            }
            
        	/*
        	try {
                return new ResponseEntity<EntityMetadata>(objectMapper.readValue("{  \"endpoints\" : [ {    \"method\" : \"HTTP-POST\",    \"type\" : \"SSOService\",    \"url\" : \"https://esmo.uji.es/gw/saml/idp/SSOService.php\"  }, {    \"method\" : \"HTTP-POST\",    \"type\" : \"SSOService\",    \"url\" : \"https://esmo.uji.es/gw/saml/idp/SSOService.php\"  } ],  \"microservice\" : [ \"microservice\", \"microservice\" ],  \"otherData\" : [ {    \"attributeMappingToEIDAS\" : {      \"displayName\" : \"CurrentGivenName\",      \"surname\" : \"CurrentFamilyName\"    }  } ],  \"displayNames\" : {    \"ES\" : \"UJI Proveedor de Identidad\",    \"EN\" : \"UJI Identity Provider\"  },  \"entityId\" : \"https://esmo.uji.es/gw/saml/idp/metadata.xml\",  \"encryptResponses\" : false,  \"protocol\" : \"protocol\",  \"defaultDisplayName\" : \"UJI Identity Provider\",  \"supportedEncryptionAlg\" : [ \"AES256\", \"AES512\" ],  \"claims\" : [ \"displayName\", \"surname\", \"dateOfBirth\", \"eduPersonAffiliation\" ],  \"logo\" : \"AWDGRsFbFDEfFGTNNJKKYGFVFfDDSSSDCCC==\",  \"supportedSigningAlg\" : [ \"RSA-SHA256\" ],  \"location\" : [ \"location\", \"location\" ],  \"securityKeys\" : [ {    \"usage\" : \"signing\",    \"keyType\" : \"RSAPublicKey\",    \"key\" : \"MDAACaFgw...xFgy=\"  }, {    \"usage\" : \"signing\",    \"keyType\" : \"RSAPublicKey\",    \"key\" : \"MDAACaFgw...xFgy=\"  } ],  \"signResponses\" : true}", EntityMetadata.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<EntityMetadata>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
            */
        }

        return new ResponseEntity<EntityMetadata>(HttpStatus.NOT_IMPLEMENTED);
    }

}
