package eu.esmo.gateway.cm.rest_api.services.mdmicroservices;

import eu.esmo.gateway.cm.rest_api.domain.MsMetadataList;

public interface AllMicroservicesGetService {
	
	MsMetadataList allMicroservicesGet () throws Exception;

}
