package eu.esmo.gateway.cm.rest_api.services.mdexternalentities;

import java.util.List;

public interface EntityCollectionsGetService {
	
	List<String> entityCollectionsGet () throws Exception;

}
