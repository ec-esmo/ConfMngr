package eu.esmo.gateway.cm.configuration;

public class Constants {
	private Constants() {}
	
	public final static String MS_NOT_FOUND = "Microservices not found";
	public final static String PROFILES_NOT_FOUND = "Profile files not found.";
	public final static String ATTRIBUTES_NOT_FOUND = "Attributes not found";
	public final static String JSON_SYNTAX_ERROR = "Json Syntax error";
	public final static String FILE_ERROR = "File error";
	public final static String ENTITY_NOT_FOUND = "External entity not found";
	public final static String ENTITIES_NOT_FOUND = "External entities not found";
	public final static String ENTITY_FILES_NOT_FOUND = "External entity files not found";
	public final static String INTERNAL_CONF_FILES_NOT_FOUND = "Internal configuration files not found";
	public final static String INTERNAL_CONF_NOT_FOUND = "Internal configuration not found";
    
	public final static String EWP_REGISTRY_NOT_AVAILABLE = "EWP Registry not available";
    public final static String EWP_MANIFEST_NOT_FOUND = "EWP Manifest file not found";
    public final static String EWP_NO_ESMO_HOSTS = "No ESMO hosts found in the registry";
    
    public final static String ESMO_GW_DSAREQUEST = "dsaRequest"; 
	public final static String ESMO_GW_DSARESPONSE = "dsaResponse";
}
