package eu.esmo.gateway.cm.rest_api.controllers.mdexternalentities;

import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import eu.esmo.gateway.cm.rest_api.domain.EntityMetadata;

@javax.annotation.Generated(value = "eu.esmo.gateway.cm.codegen.languages.SpringCodegen", date = "2018-12-10T12:53:06.421Z")

@Api(value = "metadata", description = "the metadata API")
public interface EntityGetApi {

    
    @ApiOperation(value = "Get the entityMetadata for the indicated external entity belonging to a determined set.", nickname = "entityGet", notes = "Get ...", response = EntityMetadata.class, tags={ "Registry", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Successful operation", response = EntityMetadata.class),
        @ApiResponse(code = 404, message = "Collection not found") })
    @RequestMapping(value = "/cm/metadata/externalEntities/{collectionId}/{entityId}",
        produces = { "application/json" }, 
        method = RequestMethod.GET)
    ResponseEntity<EntityMetadata> entityGet (@ApiParam(value = "",required=true) @PathVariable("collectionId") String collectionId,@ApiParam(value = "",required=true) @PathVariable("entityId") String entityId);


}
