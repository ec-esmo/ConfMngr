package eu.esmo.gateway.cm.rest_api.controllers.mdattributes;

import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import eu.esmo.gateway.cm.rest_api.domain.AttributeTypeList;

@javax.annotation.Generated(value = "eu.esmo.gateway.cm.codegen.languages.SpringCodegen", date = "2018-12-10T12:53:06.421Z")

@Api(value = "metadata", description = "the metadata API")
public interface AttributeSetGetApi {

    @ApiOperation(value = "Get the attribute set for the profile just specified.", nickname = "attributeSetGet", notes = "Get ...", response = AttributeTypeList.class, tags={ "Registry", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Successful operation", response = AttributeTypeList.class),
        @ApiResponse(code = 404, message = "Attribute Profile not found") })
    @RequestMapping(value = "/cm/metadata/attributes/{attrProfileId}",
        produces = { "application/json" }, 
        method = RequestMethod.GET)
    ResponseEntity<AttributeTypeList> attributeSetGet(@ApiParam(value = "",required=true) @PathVariable("attrProfileId") String attrProfileId);



}
