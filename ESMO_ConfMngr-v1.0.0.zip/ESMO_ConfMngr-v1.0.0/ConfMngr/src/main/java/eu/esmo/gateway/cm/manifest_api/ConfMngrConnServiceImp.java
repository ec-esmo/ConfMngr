package eu.esmo.gateway.cm.manifest_api;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.httpclient.NameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import eu.esmo.gateway.cm.network_api.NetworkServiceImpl;
import eu.esmo.gateway.cm.params_api.KeyStoreService;
import eu.esmo.gateway.cm.rest_api.domain.EsmoManifest;


@Service
public class ConfMngrConnServiceImp implements ConfMngrConnService
{
	private static final Logger log = LoggerFactory.getLogger(ConfMngrConnServiceImp.class);

	private KeyStoreService keyStoreService;
	
	private NetworkServiceImpl network = null;
	
	
	@Value("${gateway.cm.getEsmoMetadataPath}")
	private String getEsmoMetadataPath;
	
	
	@Autowired
	public ConfMngrConnServiceImp (KeyStoreService keyStoreServ) {
		
    //public ConfMngrConnServiceImp (ParameterService paramServ, KeyStoreService keyStoreServ) {
		//this.paramServ = paramServ;
		
        //cmUrl = this.paramServ.getParam("CONFIGURATION_MANAGER_URL");
        
        this.keyStoreService = keyStoreServ;
	}
	
	
	// /ewp/esmo-metadata
	@Override
	public EsmoManifest getEsmoManifest (String cmUrl) {
		
		EsmoManifest result = null;
		
		try {
			if (network == null)
			{
					network = new NetworkServiceImpl(keyStoreService);
			}
			List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
			
			String jsonResult = network.sendGet (cmUrl, // of the ESMO node being asked
					getEsmoMetadataPath, 
					urlParameters, 1);
			
			if (jsonResult != null) {
				//log.info("Result: "+ jsonResult);
		        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		        result = mapper.readValue(jsonResult, EsmoManifest.class);
			}
			
		}
		catch (Exception e) {
			log.error("CM exception", e);
			return null;
		}
		
		return result;
		
	}
	

	
}