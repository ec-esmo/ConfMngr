package eu.esmo.gateway.cm.rest_api.services.mdinternal;

import java.util.List;

public interface InternalConfsGetService {
	
	List<String> internalConfsGet () throws Exception;

}
