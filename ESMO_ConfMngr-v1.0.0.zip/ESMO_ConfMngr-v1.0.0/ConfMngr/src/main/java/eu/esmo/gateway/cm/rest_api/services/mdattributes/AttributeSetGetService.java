package eu.esmo.gateway.cm.rest_api.services.mdattributes;

import eu.esmo.gateway.cm.rest_api.domain.AttributeTypeList;

public interface AttributeSetGetService {
	
	AttributeTypeList attributeSetGet (String attrProfileId) throws Exception;

}
